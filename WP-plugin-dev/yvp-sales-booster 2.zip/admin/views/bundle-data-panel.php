<?php
/**
 * Bundle Data Panel Template
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div id="yvp_bundle_data" class="panel woocommerce_options_panel">
    <div class="options_group">
        <h4><?php _e('Bundle Items', 'yvp-sales-booster'); ?></h4>
        <p class="description"><?php _e('Add products to include in this bundle.', 'yvp-sales-booster'); ?></p>

        <div class="yvp-bundle-items">
            <?php if (!empty($bundle_items)): ?>
                <?php foreach ($bundle_items as $index => $item):
                    $item_product = wc_get_product($item['product_id']);
                    ?>
                    <div class="yvp-bundle-item">
                        <select class="yvp-product-search product-select"
                            name="yvp_bundle_items[<?php echo $index; ?>][product_id]">
                            <?php if ($item_product): ?>
                                <option value="<?php echo esc_attr($item['product_id']); ?>" selected>
                                    <?php echo esc_html($item_product->get_name()); ?>
                                </option>
                            <?php endif; ?>
                        </select>
                        <input type="number" class="quantity-input" name="yvp_bundle_items[<?php echo $index; ?>][quantity]"
                            value="<?php echo esc_attr($item['quantity']); ?>" min="1"
                            placeholder="<?php esc_attr_e('Qty', 'yvp-sales-booster'); ?>">
                        <span class="remove-item dashicons dashicons-trash"
                            title="<?php esc_attr_e('Remove', 'yvp-sales-booster'); ?>"></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <button type="button" class="button yvp-add-bundle-item">
            <span class="dashicons dashicons-plus"></span>
            <?php _e('Add Product', 'yvp-sales-booster'); ?>
        </button>
    </div>

    <div class="options_group yvp-pricing-options">
        <h4><?php _e('Bundle Pricing', 'yvp-sales-booster'); ?></h4>

        <p class="form-field">
            <label><?php _e('Pricing Mode', 'yvp-sales-booster'); ?></label>
        </p>

        <p class="form-field">
            <label>
                <input type="radio" name="yvp_bundle_pricing_mode" value="fixed" <?php checked($pricing_mode, 'fixed'); ?>>
                <?php _e('Fixed Price', 'yvp-sales-booster'); ?>
            </label>
            <span
                class="description"><?php _e('Set a specific price for the bundle (use the regular price field above).', 'yvp-sales-booster'); ?></span>
        </p>

        <p class="form-field">
            <label>
                <input type="radio" name="yvp_bundle_pricing_mode" value="percentage" <?php checked($pricing_mode, 'percentage'); ?>>
                <?php _e('Percentage Discount', 'yvp-sales-booster'); ?>
            </label>
            <span
                class="description"><?php _e('Apply a percentage discount on the combined price of items.', 'yvp-sales-booster'); ?></span>
        </p>

        <p class="form-field">
            <label>
                <input type="radio" name="yvp_bundle_pricing_mode" value="fixed_discount" <?php checked($pricing_mode, 'fixed_discount'); ?>>
                <?php _e('Fixed Discount', 'yvp-sales-booster'); ?>
            </label>
            <span
                class="description"><?php _e('Subtract a fixed amount from the combined price.', 'yvp-sales-booster'); ?></span>
        </p>

        <p class="form-field yvp-discount-value-field"
            style="<?php echo $pricing_mode === 'fixed' ? 'display:none;' : ''; ?>">
            <label for="yvp_bundle_discount_value"><?php _e('Discount Value', 'yvp-sales-booster'); ?></label>
            <input type="number" id="yvp_bundle_discount_value" name="yvp_bundle_discount_value"
                value="<?php echo esc_attr($discount_value); ?>" step="0.01" min="0" class="short">
            <span class="description" id="discount-value-desc">
                <?php echo $pricing_mode === 'percentage' ? '%' : get_woocommerce_currency_symbol(); ?>
            </span>
        </p>
    </div>
</div>

<script>
    jQuery(function ($) {
        // Toggle discount value visibility
        $('input[name="yvp_bundle_pricing_mode"]').on('change', function () {
            var mode = $(this).val();
            if (mode === 'fixed') {
                $('.yvp-discount-value-field').hide();
            } else {
                $('.yvp-discount-value-field').show();
                $('#discount-value-desc').text(mode === 'percentage' ? '%' : '<?php echo get_woocommerce_currency_symbol(); ?>');
            }
        });
    });
</script>